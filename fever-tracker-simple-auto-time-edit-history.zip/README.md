# Fever Tracker

A small mobile-friendly React + Firebase app. Users sign in with email/password, enter a temperature, and the app saves the reading with an automatic timestamp in Firestore.

## 1. Create a Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a **Web app** in Project Overview and copy its Firebase configuration.
3. In **Authentication → Sign-in method**, enable **Email/Password**.
4. In **Firestore Database**, create a database (production mode is fine; deploy the included rules).

## 2. Configure the app
1. The supplied `.env` is already configured for Firebase project `fever-track-b9523`.
2. Keep `.env` private and do not commit it to a public repository.
3. Keep `.env` private and do not commit it to a public repository.

## 3. Run locally
Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

## 4. Deploy to Firebase Hosting
Install the Firebase CLI and sign in:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
npm run build
firebase deploy
```

Select your Firebase project when prompted. The deployment publishes the `dist` folder and applies `firestore.rules`.

## Data and privacy
Each signed-in account can read and delete only its own readings. The Firestore path is `users/{uid}/readings/{readingId}`. Firebase web config is intended to be present in the client; Firestore security rules enforce per-user access.

## Fever labels
This app uses simple adult-oriented screening labels: below 99.5°F (no fever range), 99.5–100.3°F (slightly elevated), 100.4–102.1°F (fever), 102.2–103.9°F (high fever), and 104°F or above (very high). These are approximate, not a diagnosis. Measurement site, age, symptoms and clinical context matter. Seek urgent medical advice for severe symptoms, difficulty breathing, confusion, seizure, dehydration, or a temperature 104°F or higher. For infants under 3 months, 100.4°F or higher needs urgent medical assessment.
