import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, onSnapshot, orderBy, query, serverTimestamp, Timestamp
} from "firebase/firestore";
import { Activity, LogOut, Plus, Thermometer, Trash2, TrendingDown, TrendingUp, Clock3 } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { auth, db, firebaseConfigured } from "./firebase";
import "./style.css";

function toFahrenheit(value, unit) { return unit === "°C" ? (value * 9 / 5) + 32 : value; }
function classify(t, unit = "°F") {
  t = toFahrenheit(t, unit);
  if (t >= 104) return { label: "Very high", tone: "danger", detail: "104.0°F or above" };
  if (t >= 102.2) return { label: "High fever", tone: "danger", detail: "102.2–103.9°F" };
  if (t >= 100.4) return { label: "Fever", tone: "fever", detail: "100.4–102.1°F" };
  if (t >= 99.5) return { label: "Slightly elevated", tone: "warm", detail: "99.5–100.3°F" };
  return { label: "No fever range", tone: "normal", detail: "Below 99.5°F" };
}
function fmtDate(value) {
  if (!value) return "Saving…";
  const d = value?.toDate ? value.toDate() : new Date(value);
  return d.toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}
function App() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [readings, setReadings] = useState([]);
  const [temp, setTemp] = useState("");
  const [unit, setUnit] = useState("°F");
  const [recordedAt, setRecordedAt] = useState(() => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0,16); });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => onAuthStateChanged(auth, u => { setUser(u); setAuthReady(true); }), []);
  useEffect(() => {
    if (!user) { setReadings([]); return; }
    const q = query(collection(db, "users", user.uid, "readings"), orderBy("recordedAt", "desc"));
    return onSnapshot(q, snap => setReadings(snap.docs.map(d => ({ id: d.id, ...d.data() }))),
      e => setError(e.message));
  }, [user]);

  const chartData = useMemo(() => [...readings].reverse().map(r => ({
    time: fmtDate(r.recordedAt), temperature: Number(toFahrenheit(Number(r.temperature), r.unit || "°F").toFixed(1))
  })), [readings]);
  const latest = readings[0];
  const average = readings.length ? readings.reduce((s, r) => s + toFahrenheit(Number(r.temperature), r.unit || "°F"), 0) / readings.length : null;
  const previous = readings[1];
  const delta = latest && previous ? toFahrenheit(Number(latest.temperature), latest.unit || "°F") - toFahrenheit(Number(previous.temperature), previous.unit || "°F") : null;
  const todayCount = readings.filter(r => {
    const d = r.recordedAt?.toDate ? r.recordedAt.toDate() : new Date(r.recordedAt);
    return d.toDateString() === new Date().toDateString();
  }).length;

  async function handleAuth(e) {
    e.preventDefault(); setAuthError("");
    try {
      if (mode === "signup") await createUserWithEmailAndPassword(auth, email.trim(), password);
      else await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch (e) { setAuthError(e.message.replace("Firebase: ", "")); }
  }
  async function saveReading(e) {
    e.preventDefault(); setError("");
    const value = Number(temp);
    const fahrenheit = toFahrenheit(value, unit);
    const chosenDate = new Date(recordedAt);
    if (!Number.isFinite(value) || fahrenheit < 86 || fahrenheit > 113) {
      setError("Enter a valid body temperature (equivalent to 86–113°F)."); return;
    }
    if (Number.isNaN(chosenDate.getTime()) || chosenDate.getTime() > Date.now() + 60000) {
      setError("Choose a valid date and time that is not in the future."); return;
    }
    setSaving(true);
    try {
      await addDoc(collection(db, "users", user.uid, "readings"), {
        temperature: Number(value.toFixed(1)), unit, recordedAt: Timestamp.fromDate(chosenDate),
        createdAt: serverTimestamp(), clientRecordedAt: new Date().toISOString()
      });
      setTemp("");
    } catch (e) { setError("Could not save this reading. Check your connection and Firebase setup."); }
    finally { setSaving(false); }
  }
  async function removeReading(id) {
    if (!confirm("Delete this temperature reading?")) return;
    try { await deleteDoc(doc(db, "users", user.uid, "readings", id)); }
    catch { setError("Could not delete this reading."); }
  }

  if (!firebaseConfigured) return <Setup />;
  if (!authReady) return <div className="loading">Loading Fever Tracker…</div>;
  if (!user) return <main className="auth-wrap"><div className="auth-card">
    <div className="brand-mark"><Thermometer size={23}/></div><p className="eyebrow">PERSONAL HEALTH LOG</p>
    <h1>Fever Tracker</h1><p className="muted">Keep a clear record of temperature readings.</p>
    <form onSubmit={handleAuth} className="auth-form">
      <label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label>
      <label>Password<input type="password" required minLength="6" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label>
      {authError && <p className="error">{authError}</p>}
      <button className="primary full" type="submit">{mode === "login" ? "Sign in" : "Create account"}</button>
    </form>
    <p className="switch">{mode === "login" ? "New here?" : "Already have an account?"} <button onClick={()=>{setMode(mode==="login"?"signup":"login");setAuthError("");}}>{mode==="login"?"Create account":"Sign in"}</button></p>
  </div></main>;

  return <main className="shell">
    <header className="topbar"><div className="brand"><div className="brand-mark"><Thermometer size={21}/></div><div><strong>Fever Tracker</strong><small>Temperature journal</small></div></div>
      <button className="icon-btn" onClick={()=>signOut(auth)} title="Sign out"><LogOut size={18}/><span>Sign out</span></button></header>
    <section className="intro"><div><p className="eyebrow">YOUR HEALTH, AT A GLANCE</p><h1>Temperature log</h1><p className="muted">Record a reading. The time is added automatically.</p></div><div className="today-pill"><Clock3 size={15}/> {todayCount} {todayCount===1?"reading":"readings"} today</div></section>

    <section className="entry-card">
      <div className="entry-heading"><div><h2>Add a reading</h2><p className="muted">Enter the thermometer reading in your preferred unit.</p></div><div className="round-icon"><Plus size={19}/></div></div>
      <form className="entry-form" onSubmit={saveReading}>
        <div className="temp-input-wrap"><input aria-label={`Temperature in ${unit}`} type="number" step="0.1" placeholder={unit === "°F" ? "98.6" : "37.0"} value={temp} onChange={e=>setTemp(e.target.value)} required/><span>{unit}</span></div>
        <select className="unit-select" value={unit} onChange={e=>setUnit(e.target.value)} aria-label="Temperature unit"><option value="°F">°F</option><option value="°C">°C</option></select>
        <button className="primary save-btn" disabled={saving}>{saving?"Saving…":"Save reading"}</button>
      </form>
      <label className="time-label"><span><Clock3 size={14}/> Reading date &amp; time</span><input type="datetime-local" value={recordedAt} max={new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16)} onChange={e=>setRecordedAt(e.target.value)}/></label>
      <p className="auto-time"><Clock3 size={14}/> Defaults to now. Change it if you're entering an earlier reading.</p>
      {error && <p className="error">{error}</p>}
    </section>

    <section className="stats-grid">
      <div className="stat-card"><span className="stat-label">Latest reading</span><strong>{latest?`${Number(latest.temperature).toFixed(1)}${latest.unit || "°F"}`:"—"}</strong><span className="stat-foot">{latest?classify(Number(latest.temperature), latest.unit || "°F").label:"No readings yet"}</span></div>
      <div className="stat-card"><span className="stat-label">Latest status</span><strong className={`status-text ${latest?classify(Number(latest.temperature), latest.unit || "°F").tone:""}`}>{latest?classify(Number(latest.temperature), latest.unit || "°F").label:"—"}</strong><span className="stat-foot">{latest?fmtDate(latest.recordedAt):"Waiting for first entry"}</span></div>
      <div className="stat-card"><span className="stat-label">Average reading</span><strong>{average===null?"—":`${average.toFixed(1)}°F`}</strong><span className="stat-foot">Across {readings.length} {readings.length===1?"reading":"readings"}</span></div>
      <div className="stat-card"><span className="stat-label">Since previous</span><strong className="delta">{delta===null?"—":`${delta>0?"+":""}${delta.toFixed(1)}°F`}</strong><span className="stat-foot">{delta===null?"Need 2 readings":delta>0?<><TrendingUp size={13}/> Temperature increased</>:delta<0?<><TrendingDown size={13}/> Temperature decreased</>:"No change"}</span></div>
    </section>

    <section className="panel"><div className="panel-head"><div><h2>Temperature trend</h2><p className="muted">Readings converted to °F for comparison</p></div><span className="subtle-tag">{readings.length} total</span></div>
      {chartData.length < 2 ? <div className="empty-chart"><Activity size={25}/><p>Add at least two readings to see your trend.</p></div> :
      <div className="chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData} margin={{top:10,right:12,left:-18,bottom:5}}><CartesianGrid strokeDasharray="3 4" vertical={false} stroke="#e9edf2"/><XAxis dataKey="time" tick={{fontSize:11,fill:"#788392"}} axisLine={false} tickLine={false}/><YAxis domain={["dataMin - 0.5","dataMax + 0.5"]} tick={{fontSize:11,fill:"#788392"}} axisLine={false} tickLine={false}/><Tooltip formatter={v=>[`${Number(v).toFixed(1)}°F`,"Temperature"]}/><Line type="monotone" dataKey="temperature" stroke="#287d75" strokeWidth={2.5} dot={{r:3,fill:"#287d75"}} activeDot={{r:5}}/></LineChart></ResponsiveContainer></div>}
    </section>

    <section className="panel"><div className="panel-head"><div><h2>Reading history</h2><p className="muted">Your saved temperature records</p></div></div>
      {!readings.length ? <div className="empty-history"><Thermometer size={25}/><p>No readings yet. Add your first temperature above.</p></div> :
      <div className="history-list">{readings.map(r=>{const c=classify(Number(r.temperature), r.unit || "°F");return <div className="history-row" key={r.id}><div className="history-temp"><strong>{Number(r.temperature).toFixed(1)}{r.unit || "°F"}</strong><span>{fmtDate(r.recordedAt)}</span></div><span className={`status-chip ${c.tone}`}>{c.label}</span><button className="delete-btn" onClick={()=>removeReading(r.id)} aria-label="Delete reading"><Trash2 size={16}/></button></div>})}</div>}
    </section>
    <footer className="disclaimer"><strong>Important:</strong> This tracker is for record-keeping, not diagnosis. Fever thresholds are approximate and can vary by age and measurement method. Seek medical advice for concerning symptoms; a temperature of 104°F or above warrants prompt medical assessment. A baby under 3 months with 38°F or above needs urgent medical assessment.</footer>
  </main>;
}
function Setup(){return <main className="auth-wrap"><div className="auth-card"><div className="brand-mark"><Thermometer size={23}/></div><p className="eyebrow">ONE-TIME SETUP</p><h1>Connect Firebase</h1><p className="muted">The app is ready, but Firebase project details are not configured yet.</p><ol className="setup-list"><li>Create a Firebase project and add a Web app.</li><li>Copy <code>.env.example</code> to <code>.env</code>.</li><li>Paste your Firebase web configuration values into <code>.env</code>.</li><li>Enable Email/Password sign-in and create Firestore.</li><li>Run <code>npm run dev</code> or deploy using the README.</li></ol><p className="muted small">Your Firebase credentials are not included in this starter package.</p></div></main>}
createRoot(document.getElementById("root")).render(<App/>);